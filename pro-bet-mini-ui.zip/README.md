# PRO-BET Mini UI

Versión ligera con las pantallas principales.

Sube esta carpeta a GitHub y despliega en Vercel.